import './App.css'
import Spline from '@splinetool/react-spline';
import Navbar from './components/Navbar';

function App() {
  return (
    <>
      <Navbar />
      <main>
        <Spline scene="https://prod.spline.design/v8xFuRJTFz0PPCA6/scene.splinecode" />
      </main>
    </>
  )
}

export default App
