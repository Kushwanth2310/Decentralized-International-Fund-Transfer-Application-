

<a href="https://global-stg.transak.com?apiKey=<YOUR_API_KEY>&<QUERY_PARAMETERS>" target="_blank">
  Buy/Sell Crypto with Transak
</a>