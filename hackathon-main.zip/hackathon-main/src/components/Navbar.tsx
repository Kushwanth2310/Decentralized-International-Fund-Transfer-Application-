import { useState, useEffect } from 'react';
import { initializeApp } from 'firebase/app';
import { getAuth, signInWithPopup, GoogleAuthProvider, signOut } from 'firebase/auth';

const firebaseConfig = {
  // Replace with your Firebase config
  apiKey: "AIzaSyA2LNo5HC6BjzptkWCD9w6J76Q61-5Fn9c",
  authDomain: "iiit-una-hackathon.firebaseapp.com",
  projectId: "iiit-una-hackathon",
  storageBucket: "iiit-una-hackathon.firebasestorage.app",
  messagingSenderId: "498330367132",
  appId: "1:498330367132:web:e3349641d04a04b97de959",
  measurementId: "G-0TMNFCG8F7"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const provider = new GoogleAuthProvider();

// Configure Google Auth Provider
provider.setCustomParameters({
  prompt: 'select_account'
});

export default function Navbar() {
  const [user, setUser] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged((user) => {
      setUser(user);
      setError(null);
    });

    return () => unsubscribe();
  }, []);

  const handleSignIn = async () => {
    try {
      setError(null);
      const result = await signInWithPopup(auth, provider);
      console.log("Sign in successful", result.user);
    } catch (error: any) {
      console.error("Error signing in with Google", error);
      setError(error.message);
      if (error.code === 'auth/popup-blocked') {
        alert('Please allow popups for this website to sign in with Google');
      }
    }
  };

  const handleSignOut = async () => {
    try {
      await signOut(auth);
      console.log("Sign out successful");
    } catch (error: any) {
      console.error("Error signing out", error);
      setError(error.message);
    }
  };

  return (
    <nav style={styles.nav}>
      <div style={styles.logo}>
        <h1 style={styles.logoText}>404 BNF</h1>
      </div>
      <div style={styles.buttons}>
        {error && <div style={styles.error}>{error}</div>}
        {!user ? (
          <button onClick={handleSignIn} style={styles.button}>
            Sign in with Google
          </button>
        ) : (
          <div style={styles.userSection}>
            <span style={styles.userName}>{user.displayName}</span>
            <button onClick={handleSignOut} style={styles.button}>
              Sign Out
            </button>
            <button style={styles.button}>
            <a href="https://global-stg.transak.com?apiKey=<dd867c82-224a-4831-82fe-9d50c94410d9>" target="_blank">
              Buy/Sell Crypto with Transak
            </a>
            </button>
          </div>
        )}
      </div>
    </nav>
  );
}

const styles = {
  nav: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: '1rem',
    backgroundColor: '#000000',
    color: 'white',
    width: '100%',
    position: 'fixed' as const,
    top: 0,
    zIndex: 1000,
    '@media (max-width: 768px)': {
      padding: '0.5rem',
    },
  },
  logo: {
    display: 'flex',
    alignItems: 'center',
  },
  logoText: {
    margin: 0,
    fontSize: '1.5rem',
    color: 'white',
  },
  buttons: {
    display: 'flex',
    gap: '1rem',
  },
  button: {
    padding: '0.5rem 1rem',
    backgroundColor: '#000000',
    color: 'white',
    // border: '2px solid #ffffff',
    borderRadius: '20px',
    cursor: 'pointer',
    fontSize: '0.9rem',
    transition: 'all 0.3s ease',
    fontWeight: '500',
    '&:hover': {
      backgroundColor: '#ffffff',
      color: '#000000',
    },
  },
  userSection: {
    display: 'flex',
    alignItems: 'center',
    gap: '1rem',
    padding: '0.5rem 1rem',
    '@media (max-width: 768px)': {
      gap: '0.5rem',
      padding: '0.5rem',
    },
  },
  userName: {
    color: 'white',
    fontWeight: '500',
    fontSize: '0.9rem',
    '@media (max-width: 480px)': {
      display: 'none', // Hide username on very small screens
    },
  },
  error: {
    color: '#ff4444',
    fontSize: '0.9rem',
    marginRight: '1rem',
  },
};
