import Spline from '@splinetool/react-spline';

export default function Home() {
  return (
    <main>
      <Spline scene="https://prod.spline.design/v8xFuRJTFz0PPCA6/scene.splinecode" 
      />
    </main>
  );
}
